import { db } from "@/firebaseConfig";
import {
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  doc,
  serverTimestamp
} from "firebase/firestore";

// ⭐ ADD FEEDBACK
export async function addFeedback(message: string, email: string) {
  const colRef = collection(db, "feedback");

  return await addDoc(colRef, {
    message,
    email,
    timestamp: serverTimestamp(), // Firestore server time
  });
}

// ⭐ GET ALL FEEDBACK
export async function getAllFeedback() {
  const colRef = collection(db, "feedback");
  const snapshot = await getDocs(colRef);

  return snapshot.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
}

// ⭐ DELETE FEEDBACK
export async function deleteFeedback(id: string) {
  const docRef = doc(db, "feedback", id);
  await deleteDoc(docRef);
}
