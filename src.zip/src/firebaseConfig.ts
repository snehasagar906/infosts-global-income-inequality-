// src/firebaseConfig.ts
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB7vSNAg5kVrZIYdQXR4Ysygeu7Yzasi54",
  authDomain: "global-income-analysis.firebaseapp.com",
  projectId: "global-income-analysis",
  storageBucket: "global-income-analysis.firebasestorage.app",
  messagingSenderId: "333629751722",
  appId: "1:333629751722:web:da760c0ff2f896a4276bd3",
  measurementId: "G-7RJW04R3DN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Firestore DB so services can use it
export const db = getFirestore(app);
