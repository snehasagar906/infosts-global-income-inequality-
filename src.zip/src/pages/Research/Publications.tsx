import { Navbar } from "@/components/Navbar";
import { FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Publications() {
  const navigate = useNavigate();

  const publications = [
    {
      id: "global-inequality",
      title: "Global Inequality: Trends and Patterns (2024)",
      authors: "Equal World Research Group",
      description:
        "A detailed analysis of global inequality patterns and key shifts from 1990–2023.",
    },
    {
      id: "economic-mobility",
      title: "Economic Mobility Barriers in Developing Nations",
      authors: "Dr. A. Mehra, Prof. D. Lewis",
      description:
        "A research brief highlighting structural barriers to economic mobility.",
    },
    {
      id: "wealth-distribution",
      title: "Wealth Distribution & Tax Policy Effectiveness",
      authors: "Global Equity Council",
      description:
        "An international comparison of tax policy impacts on wealth inequality.",
    },
  ];

  return (
    <div className="min-h-screen relative text-gray-200 bg-gradient-to-br from-[#1a0b2e] via-[#230f45] to-[#0d1b3d]">
      <Navbar />

      <div className="pt-28 pb-20 px-4 relative z-10">
        <div className="container mx-auto max-w-5xl">

          {/* HEADER */}
          <div className="text-center mb-16">
            <div className="inline-block p-3 rounded-full bg-white/10 backdrop-blur mb-4">
              <FileText className="text-purple-300" size={32} />
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Publications
            </h1>

            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Explore research articles, reports, and policy papers published by the Equal World team.
            </p>
          </div>

          {/* PUBLICATION LIST */}
          <div className="space-y-6">
            {publications.map((pub) => (
              <div
                key={pub.id}
                className="glass rounded-xl p-6 bg-white/5 hover:scale-[1.02] transition cursor-pointer"
                onClick={() => navigate(`/research/publications/${pub.id}`)}
              >
                <h3 className="text-xl font-semibold text-white">{pub.title}</h3>
                <p className="text-purple-300 text-sm mt-1">
                  <strong>Authors:</strong> {pub.authors}
                </p>
                <p className="text-gray-300 mt-3">{pub.description}</p>

                <button className="mt-4 px-4 py-2 rounded-md text-white bg-gradient-to-r from-purple-500 to-blue-500 hover:opacity-90">
                  View Publication
                </button>
              </div>
            ))}
          </div>

        </div>
      </div>
    </div>
  );
}
