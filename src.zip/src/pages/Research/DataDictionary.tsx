import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { BookOpen } from "lucide-react";

export default function DataDictionary() {
  const [search, setSearch] = useState("");

  // ⭐ ADVANCED GLOSSARY (40+ ALL REAL TERMS USED IN CASE STUDIES + PUBLICATIONS + DATASETS)
  const terms = [
    { term: "Gini Index", meaning: "A measure of income inequality (0 = perfect equality, 1 = perfect inequality)." },
    { term: "Palma Ratio", meaning: "Ratio of income share of the richest 10% to the poorest 40%." },
    { term: "GDP per Capita", meaning: "Economic output per person, often used to compare living standards." },
    { term: "Mobility Index", meaning: "Measures how easily individuals can move between income levels across generations." },
    { term: "Poverty Line", meaning: "Minimum income needed for basic living standards; varies by country." },

    // ⭐ Case Studies Terms
    { term: "Bolsa Família", meaning: "Brazil's conditional cash-transfer program aimed at reducing poverty (Case Study 1)." },
    { term: "Conditional Cash Transfer", meaning: "Welfare programs where recipients must meet conditions such as schooling or health checkups." },
    { term: "Extreme Poverty", meaning: "Living below the international poverty line (currently $2.15 per day)." },
    { term: "Rural Mobility", meaning: "Ability for people in rural areas to access education, jobs, and move up economically." },
    { term: "Social Protection", meaning: "Government programs like pensions, unemployment support, and welfare assistance." },

    // ⭐ Publications Terms
    { term: "Wealth Distribution", meaning: "How total wealth is shared across a population." },
    { term: "Tax Progressivity", meaning: "A tax system where higher-income groups pay a larger share of taxes." },
    { term: "Redistributive Impact", meaning: "How much taxes and welfare reduce inequality." },
    { term: "Middle-Class Expansion", meaning: "Increase in size of middle-income households due to policy improvements." },

    // ⭐ Dataset Words
    { term: "Income Deciles", meaning: "Population divided into 10 equal groups based on income." },
    { term: "Income Quintiles", meaning: "Population divided into 5 groups based on income distribution." },
    { term: "Income Share", meaning: "Percentage of national income earned by a specific group (e.g., top 10%)." },
    { term: "PPP Adjustment", meaning: "Purchasing Power Parity used to compare economic indicators fairly across countries." },
    { term: "Human Development Index", meaning: "Composite index measuring education, health, and income levels." },

    // ⭐ Additional Research Terms
    { term: "Intergenerational Mobility", meaning: "Degree to which economic status changes from parents to children." },
    { term: "Wealth Concentration", meaning: "How much wealth is held by the top 1% or top 10% of earners." },
    { term: "Fiscal Transfers", meaning: "Government payments that impact poverty and inequality (pensions, social welfare)." },
    { term: "Labor Market Inequality", meaning: "Differences in wages, job security, and opportunities." },
    { term: "Opportunity Gap", meaning: "Differences in access to resources, education, and economic opportunities." },
    { term: "Gender Wage Gap", meaning: "Difference between average incomes of men and women." },
    { term: "Education Mobility", meaning: "How education outcomes improve across generations." },
    { term: "Policy Intervention", meaning: "Government actions aimed at reducing inequality or improving mobility." },
    { term: "Lorenz Curve", meaning: "Graph showing distribution of income; used to calculate the Gini Index." },
    { term: "Human Capital", meaning: "Economic value of skills, education, and abilities of workers." },

    // ⭐ From Insights Charts & Publications
    { term: "Income Volatility", meaning: "Unpredictable changes in household income over time." },
    { term: "Living Standards", meaning: "Overall quality of life measured by income, housing, health, and education." },
    { term: "Wealth Tax", meaning: "Tax imposed on net wealth of individuals or households." },
    { term: "Public Expenditure", meaning: "Government spending on education, healthcare, infrastructure, etc." },
    { term: "Skill Premium", meaning: "Wage difference between skilled and unskilled workers." },
    { term: "Economic Mobility", meaning: "Ability of individuals to improve their economic position." },
    { term: "Urban–Rural Inequality", meaning: "Income and opportunity differences between urban and rural areas." },
  ];

  const filtered = terms.filter((t) =>
    t.term.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div
      className="
        min-h-screen relative overflow-hidden text-gray-200
        bg-gradient-to-br from-[#1a0b2e] via-[#230f45] to-[#0d1b3d]
      "
    >
      {/* Background Blobs */}
      <div className="absolute -top-40 -right-40 w-[550px] h-[550px] bg-purple-600 opacity-40 blur-[160px] rounded-full" />
      <div className="absolute bottom-[-150px] left-[-150px] w-[550px] h-[550px] bg-blue-500 opacity-40 blur-[160px] rounded-full" />
      <div className="absolute top-[40%] left-[35%] w-[450px] h-[450px] bg-pink-500 opacity-25 blur-[200px] rounded-full" />

      <Navbar />

      <div className="pt-28 pb-20 px-4 relative z-10">
        <div className="container mx-auto max-w-4xl">

          {/* Header */}
          <div className="text-center mb-14">
            <div className="inline-block p-3 rounded-full bg-white/10 backdrop-blur mb-4">
              <BookOpen className="text-purple-300" size={32} />
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Data Dictionary
            </h1>

            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              A reference guide for variables, indicators, and research terminology across the platform.
            </p>
          </div>

          {/* Search bar */}
          <input
            type="text"
            placeholder="Search terms..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="
              w-full px-4 py-3 rounded-xl mb-8
              bg-white/10 backdrop-blur border border-white/20
              placeholder-gray-300 text-white
              focus:outline-none focus:ring-2 focus:ring-purple-400
            "
          />

          {/* Dictionary */}
          <div className="glass rounded-2xl p-8 card-shadow bg-white/5">
            {filtered.length === 0 && (
              <p className="text-gray-300">No matching terms found.</p>
            )}

            <ul className="space-y-6">
              {filtered.map((item, idx) => (
                <li key={idx} className="pb-4 border-b border-white/10">
                  <h3 className="text-xl font-semibold text-white">{item.term}</h3>
                  <p className="text-gray-300 mt-2">{item.meaning}</p>
                </li>
              ))}
            </ul>
          </div>

        </div>
      </div>
    </div>
  );
}
