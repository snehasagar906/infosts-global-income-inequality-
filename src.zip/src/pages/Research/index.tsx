import { useState } from "react";
import Datasets from "./Datasets";
import CaseStudies from "./CaseStudies";
import Publications from "./Publications";
import DataDictionary from "./DataDictionary";

export default function Research() {
  const [activeTab, setActiveTab] = useState("datasets");

  const tabs = [
    { id: "datasets", label: "Datasets" },
    { id: "case", label: "Case Studies" },
    { id: "publications", label: "Publications" },
    { id: "dictionary", label: "Data Dictionary" },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "datasets":
        return <Datasets />;
      case "case":
        return <CaseStudies />;
      case "publications":
        return <Publications />;
      case "dictionary":
        return <DataDictionary />;
      default:
        return <Datasets />;
    }
  };

  return (
    <div className="min-h-screen pt-24 px-6 pb-10 text-gray-200 bg-gradient-to-br from-[#0a0f24] via-[#10172f] to-[#192445]">

      {/* PAGE TITLE */}
      <h1 className="text-3xl font-bold text-center mb-6">
        🔬 Research Center
      </h1>

      {/* TOP TABS */}
      <div className="w-full flex justify-center">
        <div className="flex space-x-2 bg-white/10 border border-white/10 px-3 py-2 rounded-xl backdrop-blur-md">

          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium transition-all
                ${
                  activeTab === tab.id
                    ? "bg-blue-500 text-white shadow-md"
                    : "text-gray-300 hover:bg-white/10"
                }
              `}
            >
              {tab.label}
            </button>
          ))}

        </div>
      </div>

      {/* CONTENT */}
      <div className="mt-8">
        {renderContent()}
      </div>

    </div>
  );
}
