// src/pages/Research/CaseStudies.tsx
import { Navbar } from "@/components/Navbar";
import { BookOpen } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function CaseStudies() {
  const navigate = useNavigate();

  const cases = [
    {
      id: "brazil-poverty",
      title: "How Brazil Reduced Extreme Poverty (2003–2014)",
      region: "Latin America",
      description:
        "A deep dive into Brazil's Bolsa Família program, tracking its impact on child education and rural mobility.",
    },
    {
      id: "usa-inequality",
      title: "Rising Inequality in the United States",
      region: "North America",
      description:
        "Analyzes wage stagnation, wealth concentration, and policy gaps influencing widening inequality.",
    },
    {
      id: "scandinavia-mobility",
      title: "Social Mobility in Scandinavian Countries",
      region: "Europe",
      description:
        "Explores why Norway, Sweden, and Denmark consistently score highest in mobility and equal opportunity.",
    },
  ];

  return (
    <div className="min-h-screen relative text-gray-200 bg-gradient-to-br from-[#1a0b2e] via-[#230f45] to-[#0d1b3d]">
      <Navbar />

      <div className="pt-28 pb-20 px-4 relative z-10">
        <div className="container mx-auto max-w-5xl">
          {/* HEADER */}
          <div className="text-center mb-16">
            <div className="inline-block p-3 rounded-full bg-white/10 backdrop-blur mb-4">
              <BookOpen className="text-purple-300" size={32} />
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Case Studies
            </h1>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Explore evidence-based stories explaining how policy, economics,
              and society shape inequality.
            </p>
          </div>

          {/* CASE CARDS */}
          <div className="grid gap-6">
            {cases.map((c) => (
              <div
                key={c.id}
                className="glass bg-white/10 border border-white/10 rounded-xl p-6 hover:scale-[1.02] transition"
              >
                <h3 className="text-xl font-semibold text-white">{c.title}</h3>

                <p className="text-gray-300 text-sm mt-1">
                  <strong className="text-purple-300">Region:</strong>{" "}
                  {c.region}
                </p>

                <p className="text-gray-300 mt-3">{c.description}</p>

                <button
                  onClick={() =>
                    navigate(`/research/case-studies/${c.id}`)
                  }
                  className="mt-4 px-4 py-2 rounded-md text-white bg-gradient-to-r from-purple-500 to-blue-500 hover:opacity-90"
                >
                  View Full Study
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
