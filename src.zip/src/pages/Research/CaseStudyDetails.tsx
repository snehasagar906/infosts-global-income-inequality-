// src/pages/Research/CaseStudyDetails.tsx

import { useParams } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import jsPDF from "jspdf";

export default function CaseStudyDetails() {
  const { id } = useParams();

  // ===========================================
  // CASE STUDY DATA (FULL CONTENT + INSIGHTS)
  // ===========================================
  const caseStudies: any = {
    "brazil-poverty": {
      title: "How Brazil Reduced Extreme Poverty (2003–2014)",
      summary:
        "Brazil’s Bolsa Família program greatly reduced extreme poverty through targeted welfare, improving both education and healthcare outcomes.",
      sections: [
        {
          heading: "Poverty Reduction Trend",
          text: "Brazil experienced a dramatic decline in poverty after implementing Bolsa Família and expanding social programs.",
          chart: [
            { year: 2003, value: 34 },
            { year: 2006, value: 28 },
            { year: 2009, value: 21 },
            { year: 2012, value: 16 },
            { year: 2014, value: 12 },
          ],
          insights: [
            "The steep decline between 2003–2009 reflects effective early program targeting.",
            "Conditional incentives for education & healthcare helped stabilize long-term poverty reduction.",
            "The slowdown after 2012 suggests diminishing returns without deeper structural reforms.",
          ],
        },
        {
          heading: "Education Access Improvements",
          text: "School enrollment rose sharply due to education-linked welfare conditions, especially in rural regions.",
          chart: [
            { year: 2003, value: 72 },
            { year: 2006, value: 78 },
            { year: 2009, value: 85 },
            { year: 2012, value: 91 },
          ],
          insights: [
            "Enrollment growth strongly correlates with Bolsa Família requirements.",
            "Rural areas benefited most, reducing regional gaps in education.",
            "Higher enrollment is projected to improve long-term social mobility.",
          ],
        },
      ],
    },

    // --------------------------------------------------
    "usa-inequality": {
      title: "Rising Inequality in the United States",
      summary:
        "Income inequality continues to rise in the United States due to wage stagnation, rising executive pay, weak labor unions, and declining upward mobility.",
      sections: [
        {
          heading: "Income Gap Over Time",
          text: "The income share of the top 10% has increased steadily since the 1990s.",
          chart: [
            { year: 1990, value: 30 },
            { year: 2000, value: 35 },
            { year: 2010, value: 41 },
            { year: 2020, value: 45 },
          ],
          insights: [
            "The top 10% income share grew at its fastest pace between 2000–2010.",
            "Wage stagnation among middle-income workers widened the income divide.",
            "Shrinking labor bargaining power contributes to earnings inequality.",
          ],
        },
        {
          heading: "Middle-Class Shrinking",
          text: "Middle-income households represent a decreasing portion of national income.",
          chart: [
            { year: 1990, value: 50 },
            { year: 2000, value: 46 },
            { year: 2010, value: 43 },
            { year: 2020, value: 39 },
          ],
          insights: [
            "Middle-class erosion is linked to rising living costs and stagnant wages.",
            "Higher debt levels reduce long-term economic stability for households.",
            "This trend signals declining social mobility opportunities.",
          ],
        },
      ],
    },

    // --------------------------------------------------
    "scandinavia-mobility": {
      title: "Social Mobility in Scandinavian Countries",
      summary:
        "Scandinavian countries maintain the world's highest mobility rates due to universal welfare, strong public services, and low inequality.",
      sections: [
        {
          heading: "Mobility Index Comparison",
          text: "Mobility scores consistently remain high across Scandinavian nations.",
          chart: [
            { year: 2000, value: 80 },
            { year: 2005, value: 82 },
            { year: 2010, value: 85 },
            { year: 2015, value: 87 },
          ],
          insights: [
            "Mobility improves gradually, reflecting stability in social programs.",
            "Education access and quality directly support upward mobility.",
            "The mobility gap between Scandinavia and other regions is widening.",
          ],
        },
        {
          heading: "Gini Index Stability",
          text: "Low levels of inequality help sustain strong social mobility.",
          chart: [
            { year: 2000, value: 25 },
            { year: 2005, value: 24 },
            { year: 2010, value: 23 },
            { year: 2015, value: 22 },
          ],
          insights: [
            "Stable Gini values show long-term policy consistency.",
            "Low inequality reduces intergenerational wealth barriers.",
            "Welfare-focused systems minimize socioeconomic divides.",
          ],
        },
      ],
    },
  };

  // ===========================================
  // Load selected story
  // ===========================================
  const study = caseStudies[id ?? ""];

  if (!study) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white text-2xl">
        Case Study Not Found
      </div>
    );
  }

  // PDF Export Function
  const downloadPDF = () => {
    const pdf = new jsPDF("p", "pt", "a4");
    pdf.text(study.title, 40, 40);
    pdf.text(study.summary, 40, 80);
    pdf.save(`${study.title}.pdf`);
  };

  return (
    <div className="min-h-screen text-gray-200 bg-gradient-to-br from-[#0b1023] via-[#1a1440] to-[#0a1a32]">
      <Navbar />

      <div className="pt-28 pb-20 px-6 container mx-auto max-w-4xl">

        {/* TITLE */}
        <h1 className="text-4xl font-bold text-white mb-4">{study.title}</h1>
        <p className="text-lg text-gray-300 mb-8">{study.summary}</p>

        {/* DOWNLOAD PDF BUTTON */}
        <button
          onClick={downloadPDF}
          className="mb-10 px-4 py-2 rounded-md bg-purple-600 hover:bg-purple-700 text-white shadow-lg"
        >
          Download PDF
        </button>

        {/* ======================================================
            SECTION BLOCKS
        ====================================================== */}
        {study.sections.map((section: any, index: number) => (
          <div key={index} className="glass bg-white/10 p-6 mb-10 rounded-xl">

            {/* Section Title */}
            <h2 className="text-2xl font-semibold text-white mb-2">
              {section.heading}
            </h2>
            <p className="text-gray-300 mb-4">{section.text}</p>

            {/* CHART */}
            <div className="h-64 mb-6">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={section.chart}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
                  <XAxis dataKey="year" stroke="#ccc" />
                  <YAxis stroke="#ccc" />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#a78bfa"
                    strokeWidth={3}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* INSIGHTS SECTION */}
            <div className="mt-6 bg-black/20 border border-white/10 rounded-xl p-5">
              <h3 className="text-xl font-semibold text-purple-300 mb-3">
                Insights
              </h3>

              <ul className="text-gray-300 space-y-2 text-sm">
                {section.insights.map((insight: string, i: number) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-purple-400">•</span>
                    {insight}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}

        {/* FINAL TAKEAWAYS */}
        <div className="glass bg-white/10 p-6 mt-10 rounded-xl">
          <h2 className="text-2xl font-bold text-white mb-3">Key Takeaways</h2>

          <ul className="space-y-3 text-gray-300 text-sm">
            <li className="flex gap-2">
              <span className="text-blue-400">•</span>
              Case studies reveal how policy decisions influence long-term socioeconomic outcomes.
            </li>

            <li className="flex gap-2">
              <span className="text-blue-400">•</span>
              Education, welfare, and income distribution remain critical drivers of inequality trends.
            </li>

            <li className="flex gap-2">
              <span className="text-blue-400">•</span>
              Data-based insights help understand patterns and guide policy recommendations.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
