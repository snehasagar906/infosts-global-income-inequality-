import { useParams } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

/* ------------------------------------------------------
   MOCK CHART DATA (same for all publications — customizable)
------------------------------------------------------- */
const chartData = [
  { year: 2000, value: 45 },
  { year: 2005, value: 42 },
  { year: 2010, value: 40 },
  { year: 2015, value: 38 },
  { year: 2020, value: 36 },
];

/* ------------------------------------------------------
   FULL PUBLICATION CONTENT DATABASE
------------------------------------------------------- */
const publications: Record<string, any> = {
  "global-inequality": {
    title: "Global Inequality: Trends and Patterns (2024)",
    authors: "Equal World Research Group",
    summary:
      "This publication analyzes inequality trends across 160 countries, highlighting key patterns in the global distribution of income and wealth.",

    sections: [
      {
        heading: "Global Gini Index Trend",
        text: "The global Gini index shows modest declines since 2005 but remains historically high.",
      },
      {
        heading: "Wealth Gap Analysis",
        text: "Wealth inequality continues to widen due to asset concentration in top income groups.",
      },
    ],
  },

  "economic-mobility": {
    title: "Economic Mobility Barriers in Developing Nations",
    authors: "Dr. A. Mehra, Prof. D. Lewis",
    summary:
      "This study examines structural barriers to social mobility and proposes evidence-based policy reforms for developing nations.",

    sections: [
      {
        heading: "Education & Mobility",
        text: "Low education access remains one of the strongest predictors of limited mobility.",
      },
      {
        heading: "Labor Market Inequality",
        text: "Informal sector dominance and wage inequality hinder long-term economic progress.",
      },
    ],
  },

  "wealth-distribution": {
    title: "Wealth Distribution & Tax Policy Effectiveness",
    authors: "Global Equity Council",
    summary:
      "Evaluates how tax reforms impact wealth inequality and middle-class expansion across regions.",

    sections: [
      {
        heading: "Wealth Concentration Trends",
        text: "The wealth share of the top 1% continues to rise across advanced and emerging economies.",
      },
      {
        heading: "Effectiveness of Tax Reforms",
        text: "Countries with progressive taxation report moderate reductions in wealth inequality.",
      },
      {
        heading: "Impact on Middle-Class Growth",
        text: "Middle-class expansion is closely linked to equitable tax structures and social protection programs.",
      },
    ],
  },
};

/* ------------------------------------------------------
   PDF FILE MAPPING
------------------------------------------------------- */
const pdfMap: Record<string, string> = {
  "global-inequality": "/pdfs/global_inequality_report.pdf",
  "economic-mobility": "/pdfs/economic_mobility_barriers.pdf",
  "wealth-distribution": "/pdfs/wealth_distribution_tax_policy.pdf",
};

/* ------------------------------------------------------
   MAIN COMPONENT
------------------------------------------------------- */
export default function PublicationDetails() {
  const { id } = useParams();

  const publication = id ? publications[id] : null;
  const pdfPath = id ? pdfMap[id] : null;

  if (!publication) {
    return (
      <div
        className="min-h-screen flex items-center justify-center
                   bg-gradient-to-br from-[#1a0b2e] via-[#230f45] to-[#0d1b3d]"
      >
        <h1 className="text-white text-3xl font-semibold">Publication Not Found</h1>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen relative overflow-hidden text-gray-200
                 bg-gradient-to-br from-[#1a0b2e] via-[#230f45] to-[#0d1b3d]"
    >
      {/* Background Glows */}
      <div className="absolute -top-40 -right-40 w-[550px] h-[550px] rounded-full bg-purple-600 opacity-40 blur-[160px]" />
      <div className="absolute bottom-[-150px] left-[-150px] w-[550px] h-[550px] rounded-full bg-blue-500 opacity-40 blur-[160px]" />

      <Navbar />

      {/* PAGE CONTENT */}
      <div className="pt-28 pb-20 px-6 relative z-10 max-w-5xl mx-auto">
        
        {/* Title */}
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-3">
          {publication.title}
        </h1>

        {/* Authors */}
        <p className="text-purple-300 font-semibold mb-6">
          Authors: {publication.authors}
        </p>

        {/* Summary */}
        <p className="text-gray-300 max-w-3xl mb-6">{publication.summary}</p>

        {/* PDF Button */}
        <a
          href={pdfPath}
          target="_blank"
          rel="noopener noreferrer"
          className="
            inline-block mt-3 px-5 py-2 rounded-md text-white
            bg-gradient-to-r from-purple-500 to-blue-500
            hover:opacity-90 transition-all shadow-md
          "
        >
          View PDF
        </a>

        {/* SECTIONS WITH CHARTS */}
        <div className="mt-12 space-y-10">
          {publication.sections.map((section: any, index: number) => (
            <div
              key={index}
              className="glass bg-white/10 border border-white/10
                         backdrop-blur-xl rounded-2xl p-6"
            >
              <h2 className="text-2xl font-semibold text-white mb-2">
                {section.heading}
              </h2>

              <p className="text-gray-300 mb-4">{section.text}</p>

              {/* Chart */}
              <div style={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff30" />
                    <XAxis dataKey="year" stroke="#ccc" />
                    <YAxis stroke="#ccc" />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#a78bfa"
                      strokeWidth={2}
                      dot={true}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
