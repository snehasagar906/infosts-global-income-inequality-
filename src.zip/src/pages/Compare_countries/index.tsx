import { useState } from "react";
import CompareMetrics from "./CompareMetrics";
import MultiTimeline from "./MultiTimeline";
import MetricSummary from "./MetricSummary";

export default function CompareCountries() {
  const [activeTab, setActiveTab] = useState("metrics");

  const tabs = [
    { id: "metrics", label: "Compare Metrics" },
    { id: "multi", label: "Multi Timeline" },
    { id: "summary", label: "Metric Summary" },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "metrics":
        return <CompareMetrics />;
      case "multi":
        return <MultiTimeline />;
      case "summary":
        return <MetricSummary />;
      default:
        return <CompareMetrics />;
    }
  };

  return (
    <div className="min-h-screen pt-24 px-6 pb-10 text-gray-200 bg-gradient-to-br from-[#0a0f24] via-[#10172f] to-[#192445]">

      {/* PAGE TITLE */}
      <h1 className="text-3xl font-bold text-center mb-6">
      📊 Compare Countries
      </h1>

      {/* TOP TABS */}
      <div className="w-full flex justify-center">
        <div className="flex space-x-2 bg-white/10 border border-white/10 px-3 py-2 rounded-xl backdrop-blur-md">

          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium transition-all
                ${
                  activeTab === tab.id
                    ? "bg-blue-500 text-white shadow-md"
                    : "text-gray-300 hover:bg-white/10"
                }
              `}
            >
              {tab.label}
            </button>
          ))}

        </div>
      </div>

      {/* CONTENT */}
      <div className="mt-8">
        {renderContent()}
      </div>

    </div>
  );
}
