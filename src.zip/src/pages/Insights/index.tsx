import { useState } from "react";
import MobilityTimeline from "./MobilityTimeline";
import OpportunityCalculator from "./OpportunityCalculator";
import PolicyImpactSimulator from "./PolicyImpactSimulator";
import FactorBreakdown from "./FactorBreakdown";

export default function Insights() {
  const [activeTab, setActiveTab] = useState("mobility");

  const tabs = [
    { id: "mobility", label: "Mobility Timeline" },
    { id: "opportunity", label: "Opportunity Calculator" },
    { id: "policy", label: "Policy Impact Simulator" },
    { id: "factors", label: "Factor Breakdown" },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "mobility":
        return <MobilityTimeline />;
      case "opportunity":
        return <OpportunityCalculator />;
      case "policy":
        return <PolicyImpactSimulator />;
      case "factors":
        return <FactorBreakdown />;
      default:
        return <MobilityTimeline />;
    }
  };

  return (
    <div className="min-h-screen pt-24 px-6 pb-10 text-gray-200 bg-gradient-to-br from-[#0a0f24] via-[#10172f] to-[#192445]">

      {/* PAGE TITLE */}
      <h1 className="text-3xl font-bold text-center mb-6">
        💡 Insights
      </h1>

      {/* TOP TABS */}
      <div className="w-full flex justify-center">
        <div className="flex space-x-2 bg-white/10 border border-white/10 px-3 py-2 rounded-xl backdrop-blur-md">

          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium transition-all
                ${
                  activeTab === tab.id
                    ? "bg-blue-500 text-white shadow-md"
                    : "text-gray-300 hover:bg-white/10"
                }
              `}
            >
              {tab.label}
            </button>
          ))}

        </div>
      </div>

      {/* CONTENT */}
      <div className="mt-8">
        {renderContent()}
      </div>

    </div>
  );
}
