import { useState } from "react";
import Overview from "./Overview";
import GlobalHeatmap from "./GlobalHeatmap";
import TrendTime from "./TrendTime";
import VariableCorrelations from "./VariableCorrelations";
import UploadMerge from "./UploadMerge";

export default function DataExplorer() {
  const [activeTab, setActiveTab] = useState("overview");

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "global-heatmap", label: "Global Heatmap" },
    { id: "trend-time", label: "Trend & Time Analysis" },
    { id: "correlations", label: "Variable Correlations" },
    { id: "upload-merge", label: "Upload & Merge" },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "overview":
        return <Overview />;
      case "global-heatmap":
        return <GlobalHeatmap />;
      case "trend-time":
        return <TrendTime />;
      case "correlations":
        return <VariableCorrelations />;
      case "upload-merge":
        return <UploadMerge />;
      default:
        return <Overview />;
    }
  };

  return (
    <div className="min-h-screen pt-24 px-6 pb-10 bg-gradient-to-br from-[#0a0f24] via-[#10172f] to-[#192445] text-gray-200">

      {/* PAGE TITLE */}
      <h1 className="text-3xl font-bold text-center mb-6">
        📊 Data Explorer
      </h1>

      {/* TOP TABS */}
      <div className="w-full flex justify-center">
        <div className="flex space-x-2 bg-white/10 border border-white/10 px-3 py-2 rounded-xl backdrop-blur-md">

          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium transition-all
                ${activeTab === tab.id
                  ? "bg-blue-500 text-white shadow-md"
                  : "text-gray-300 hover:bg-white/10"}
              `}
            >
              {tab.label}
            </button>
          ))}

        </div>
      </div>

      {/* CONTENT SECTION */}
      <div className="mt-8">
        {renderContent()}
      </div>
    </div>
  );
}
