import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "./components/ThemeProvider";
import { ProtectedRoute } from "@/components/ProtectedRoute";

// GLOBAL WIDGETS
import ChatbotWidget from "@/components/Chatbot";
import FeedbackWidget from "@/components/FeedbackWidget";

// AUTH & BASE PAGES
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import Timeline from "./pages/Timeline";
import Admin from "./pages/Admin";
import NotFound from "./pages/NotFound";

// DASHBOARDS
import Dashboard1 from "./pages/Dashboard1Enhanced";
import Dashboard2 from "./pages/Dashboard2Enhanced";
import Dashboard3 from "./pages/Dashboard3Enhanced";

// ⭐ TAB MAIN PAGES
import DataExplorer from "./pages/Data_explorer/index";
import CountryProfiles from "./pages/Country_profile/index";
import CompareCountries from "./pages/Compare_countries/index";
import Insights from "./pages/Insights/index";
import Research from "./pages/Research/index";

// ⭐ CASE STUDY PAGES
import CaseStudies from "./pages/Research/CaseStudies";
import CaseStudyDetails from "./pages/Research/CaseStudyDetails";

// ⭐ PUBLICATIONS DETAILS PAGE
import PublicationDetails from "./pages/Research/PublicationDetails";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />

        <BrowserRouter>
          {/* Global Widgets: visible everywhere */}
          <ChatbotWidget />
          <FeedbackWidget />

          <Routes>
            {/* ---------------- PUBLIC ROUTES ---------------- */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            {/* ---------------- PROTECTED ROUTES ---------------- */}
            <Route
              path="/home"
              element={<ProtectedRoute><Home /></ProtectedRoute>}
            />

            <Route
              path="/contact"
              element={<ProtectedRoute><Contact /></ProtectedRoute>}
            />

            <Route
              path="/timeline"
              element={<ProtectedRoute><Timeline /></ProtectedRoute>}
            />

            <Route
              path="/admin"
              element={<ProtectedRoute><Admin /></ProtectedRoute>}
            />

            {/* ---------------- DASHBOARDS ---------------- */}
            <Route
              path="/dashboard1"
              element={<ProtectedRoute><Dashboard1 /></ProtectedRoute>}
            />

            <Route
              path="/dashboard2"
              element={<ProtectedRoute><Dashboard2 /></ProtectedRoute>}
            />

            <Route
              path="/dashboard3"
              element={<ProtectedRoute><Dashboard3 /></ProtectedRoute>}
            />

            {/* ---------------- TAB ROUTES ---------------- */}
            <Route
              path="/data-explorer"
              element={<ProtectedRoute><DataExplorer /></ProtectedRoute>}
            />

            <Route
              path="/country-profiles"
              element={<ProtectedRoute><CountryProfiles /></ProtectedRoute>}
            />

            <Route
              path="/compare-countries"
              element={<ProtectedRoute><CompareCountries /></ProtectedRoute>}
            />

            <Route
              path="/insights"
              element={<ProtectedRoute><Insights /></ProtectedRoute>}
            />

            <Route
              path="/research"
              element={<ProtectedRoute><Research /></ProtectedRoute>}
            />

            {/* ---------------- CASE STUDIES ---------------- */}
            <Route
              path="/research/case-studies"
              element={<ProtectedRoute><CaseStudies /></ProtectedRoute>}
            />

            <Route
              path="/research/case-studies/:id"
              element={<ProtectedRoute><CaseStudyDetails /></ProtectedRoute>}
            />

            {/* ---------------- PUBLICATIONS ---------------- */}
            <Route
              path="/research/publications/:id"
              element={<ProtectedRoute><PublicationDetails /></ProtectedRoute>}
            />

            {/* ---------------- 404 PAGE ---------------- */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
