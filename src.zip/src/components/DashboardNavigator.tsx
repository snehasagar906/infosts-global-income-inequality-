import { useLocation, useNavigate } from "react-router-dom";

const dashboards = [
  { name: "Global Overview", path: "/dashboard1" },
  { name: "Inequality Trends", path: "/dashboard2" },
  { name: "Country Deep Dive", path: "/dashboard3" },
];

export default function DashboardNavigator() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <div className="mb-8 flex justify-center">
      {/* ✅ NAVBAR CONTAINER (Same as Data Explorer Style) */}
      <div
        className="
          flex gap-2
          bg-[#1b1f36] 
          p-2 
          rounded-2xl 
          shadow-lg
          border border-white/10
          backdrop-blur-xl
        "
      >
        {dashboards.map((dash) => {
          const active = location.pathname === dash.path;

          return (
            <button
              key={dash.path}
              onClick={() => navigate(dash.path)}
              className={`
                px-6 py-2
                rounded-xl
                text-sm font-semibold
                transition-all duration-300
                ${
                  active
                    ? "bg-blue-500 text-white shadow-md"
                    : "text-white/70 hover:text-white hover:bg-white/10"
                }
              `}
            >
              {dash.name}
            </button>
          );
        })}
      </div>
    </div>
  );
}
