// src/components/Chatbot.tsx
import { useState } from "react";
import OpenAI from "openai";

export default function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([
    { from: "bot", text: "Hi! How can I help you today?" },
  ]);
  const [loading, setLoading] = useState(false);

  // READ KEY FROM VITE ENV (make sure .env has VITE_OPENAI_API_KEY)
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY || "";
  const client = apiKey
    ? new OpenAI({ apiKey, dangerouslyAllowBrowser: true })
    : null;

  const handleSend = async () => {
    if (!input.trim()) return;

    setMessages((prev) => [...prev, { from: "user", text: input }]);
    const userMessage = input;
    setInput("");
    setLoading(true);

    try {
      if (!client) {
        setMessages((prev) => [
          ...prev,
          { from: "bot", text: "API key missing — cannot send request." },
        ]);
        setLoading(false);
        return;
      }

      const response = await client.responses.create({
        model: "gpt-4o-mini",
        input: userMessage,
      });

      // safe extraction: prefer output_text, otherwise parse content array
      const botReply =
        (response as any).output_text ||
        ((response as any).output
          ?.map((it: any) =>
            (it?.content || []).map((c: any) => c?.text || "").join(" ")
          )
          .join(" ") || "Sorry — I couldn't understand.");

      setMessages((prev) => [...prev, { from: "bot", text: botReply }]);
    } catch (err) {
      console.error("Chatbot error:", err);
      setMessages((prev) => [
        ...prev,
        { from: "bot", text: "Error generating response." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating button: high z-index so it's clickable */}
      <button
        onClick={() => setOpen((o) => !o)}
        className="fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg z-[9999] pointer-events-auto"
        aria-label="Open chat"
      >
        💬
      </button>

      {/* Chat window: high z-index and pointer-events enabled */}
      {open && (
        <div
          className="fixed bottom-24 right-6 w-80 bg-white dark:bg-gray-900 border rounded-xl shadow-xl p-4 h-96 flex flex-col z-[9999] pointer-events-auto"
          role="dialog"
          aria-modal="true"
        >
          <h2 className="font-semibold mb-2 text-black dark:text-white">
            Chatbot Assistant
          </h2>

          <div className="flex-1 overflow-y-auto mb-3 space-y-2">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`p-2 rounded-lg max-w-[90%] ${
                  msg.from === "user"
                    ? "bg-blue-600 text-white self-end"
                    : "bg-gray-200 dark:bg-gray-700 text-black dark:text-white self-start"
                }`}
              >
                {msg.text}
              </div>
            ))}
            {loading && <div className="text-gray-500 text-sm">Typing...</div>}
          </div>

          <div className="flex gap-2">
            <input
              className="flex-1 border rounded-lg p-2 dark:bg-gray-800 dark:text-white"
              placeholder="Type a message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSend();
              }}
            />
            <button
              onClick={handleSend}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg"
            >
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
}
