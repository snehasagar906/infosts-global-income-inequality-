import { Link, NavLink, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { logout, getCurrentUser, isAuthenticated } from "@/lib/auth";
import { BarChart3, LogOut, Menu, X } from "lucide-react";
import { useRef, useState, useEffect } from "react";
import { ThemeToggle } from "./ThemeToggle";

export const Navbar = () => {
  const navigate = useNavigate();
  const user = getCurrentUser();
  const authenticated = isAuthenticated();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  /** -----------------------------------------
   * NEW CLEAN MENU STRUCTURE — ALL DIRECT LINKS
   * ----------------------------------------- */
  const menus = [
    { label: "Data Explorer", path: "/data-explorer" },
    { label: "Country Profiles", path: "/country-profiles" },
    { label: "Compare Countries", path: "/compare-countries" },
    { label: "Insights", path: "/insights" },
    { label: "Research", path: "/research" },
  ];

  /** Close mobile dropdown when clicking outside */
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (navRef.current && !navRef.current.contains(e.target as Node)) {
        setMobileMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav
      ref={navRef}
      className="
        fixed top-0 left-0 right-0 z-50
        bg-white/10 backdrop-blur-2xl
        border-b border-white/10
        shadow-lg text-white
      "
    >
      <div className="container mx-auto px-5">
        <div className="flex items-center justify-between h-16">

          {/* LOGO */}
          <Link
            to={authenticated ? "/home" : "/"}
            className="flex items-center gap-2 text-xl font-bold"
          >
            <BarChart3 size={26} className="text-white" />
            <span className="bg-gradient-to-r from-white to-white/70 bg-clip-text text-transparent">
              Global Insights
            </span>
          </Link>

          {/* DESKTOP NAV */}
          <div className="hidden md:flex items-center gap-8">

            {menus.map((menu) => (
              <NavLink
                key={menu.path}
                to={menu.path}
                className="hover:text-white/80 whitespace-nowrap transition"
              >
                {menu.label}
              </NavLink>
            ))}

            {/* SIMPLE LINKS */}
            <NavLink to="/timeline" className="hover:text-white/80">
              Timeline
            </NavLink>

            <NavLink to="/contact" className="hover:text-white/80">
              Contact
            </NavLink>

            {authenticated && user?.email === "admin@gmail.com" && (
              <NavLink to="/admin" className="hover:text-white/80">
                Admin
              </NavLink>
            )}

            <ThemeToggle />

            {/* USER INFO + LOGOUT */}
            {authenticated && (
              <div className="flex items-center gap-3">
                <span className="text-sm text-white/80">
                  Welcome, {user?.name || user?.email}
                </span>

                <Button
                  onClick={handleLogout}
                  size="sm"
                  className="bg-white/20 hover:bg-white/30 text-white rounded-xl px-4"
                >
                  <LogOut size={16} className="mr-1" />
                  Logout
                </Button>
              </div>
            )}

          </div>

          {/* MOBILE MENU TOGGLE */}
          <button
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

        </div>
      </div>

      {/* MOBILE MENU */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-black/90 p-5 border-t border-white/10">
          <div className="flex flex-col gap-4 text-white">

            {menus.map((menu) => (
              <NavLink
                key={menu.path}
                to={menu.path}
                onClick={() => setMobileMenuOpen(false)}
                className="text-lg"
              >
                {menu.label}
              </NavLink>
            ))}

            <NavLink to="/timeline" onClick={() => setMobileMenuOpen(false)}>
              Timeline
            </NavLink>

            <NavLink to="/contact" onClick={() => setMobileMenuOpen(false)}>
              Contact
            </NavLink>

            {authenticated && user?.email === "admin@gmail.com" && (
              <NavLink to="/admin" onClick={() => setMobileMenuOpen(false)}>
                Admin
              </NavLink>
            )}

            {authenticated && (
              <Button
                onClick={handleLogout}
                size="sm"
                className="bg-white/20 hover:bg-white/30 text-white rounded-xl mt-3"
              >
                <LogOut size={16} className="mr-2" />
                Logout
              </Button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
